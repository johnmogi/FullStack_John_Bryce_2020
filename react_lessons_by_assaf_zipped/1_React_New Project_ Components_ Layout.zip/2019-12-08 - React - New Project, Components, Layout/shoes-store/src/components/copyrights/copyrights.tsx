import React, { Component } from "react";
import "./copyrights.css";

export class Copyrights extends Component {
    public render(): JSX.Element {
        return (
            <div className="copyrights">
                <p>All Rights Reserved &copy;</p>
            </div>
        );
    }
}

