import React, { Component } from "react";
import "./layout.css";
import { Header } from "../header/header";
import { Copyrights } from "../copyrights/copyrights";
import { Main } from "../main/main";

export class Layout extends Component {

    // The render function will return the component UI
    public render(): JSX.Element {
        return (
            <div className="layout">

                <header>
                    <Header />
                </header>

                <main>
                    <Main />
                </main>

                <footer>
                    <Copyrights />
                </footer>

            </div>
        );
    }
}