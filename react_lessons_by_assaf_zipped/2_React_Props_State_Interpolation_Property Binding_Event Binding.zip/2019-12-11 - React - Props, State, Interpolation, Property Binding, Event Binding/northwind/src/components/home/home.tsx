import React, { Component } from "react";
import "./home.css";

interface HomeState {
    currentDiscount: number;
    imageWidth: number;
}

export class Home extends Component<any, HomeState> {

    public constructor(props: any) {
        super(props);
        this.state = {
            currentDiscount: 12,
            imageWidth: 300
        };
    }

    public render(): JSX.Element {
        return (
            <div className="home">

                {/* Interpolation:  */}
                <p>Only now, {this.state.currentDiscount}% discount on all products!</p>

                {/* Property Binding:  */}
                <img src="/assets/images/home.png" width={this.state.imageWidth} />

                <section>

                    {/* Event Binding:  */}
                    <button onClick={this.decreaseImage}>&darr;</button>
                    <button onClick={this.resetImage}>&harr;</button>
                    <button onClick={this.increaseImage}>&uarr;</button>

                </section>

            </div>
        );
    }

    private decreaseImage = () => {
        if (this.state.imageWidth > 100) {
            this.setState({ imageWidth: this.state.imageWidth - 10 });
        }
    };

    private resetImage = () => {
        this.setState({ imageWidth: 300 });
    };

    private increaseImage = () => {
        if (this.state.imageWidth < 500) {
            this.setState({ imageWidth: this.state.imageWidth + 10 });
        }
    };

}