if (f1() || f2()) {
    console.log(":-)");
}
else {
    console.log(":-(");
}

function f1() {
    console.log("f1");
    return true;
}

function f2() {
    console.log("f2");
    return true;
}
