
function test() {

    const arr = [12, 23, 34, 45, 56, 67, 78, 89, 90];

    // מציאת המספר הראשון הגדול מ-50
    const result1 = arr.find(n => n > 50);
    document.write("First value larger than 50: " + result1 + "<br>");

    // מציאת כל הזוגיים
    const result2 = arr.filter(n => n % 2 === 0);
    document.write("All even numbers: " + result2 + "<br>");

    // "Odd" או "Even" עבור כל מספר, להציג
    const result3 = arr.map(n => n % 2 === 0 ? "Even" : "Odd");
    document.write("All numbers - Even or Odd: " + result3 + "<br>");

    // הצגת סכום הפריטים
    const result4 = arr.reduce((sum, n) => sum + n, 0);
    document.write("Summary: " + result4 + "<br>");

    const cats = [{ name: "Mitsi", age: 4 }, { name: "Kitsi", age: 5 }, { name: "Pitsi", age: 6 }];

    const result5 = cats.find(c => c.name[0].toLowerCase() == "k");
    document.write("First cat starting with K: " + result5.name + ", " + result5.age + "<br>");

    const result6 = cats.filter(c => c.age > 4);
    document.write("All cats older than 4: ");
    for (const c of result6) {
        document.write(c.name + ", " + c.age + " | ");
    }
    document.write("<br>");







}

