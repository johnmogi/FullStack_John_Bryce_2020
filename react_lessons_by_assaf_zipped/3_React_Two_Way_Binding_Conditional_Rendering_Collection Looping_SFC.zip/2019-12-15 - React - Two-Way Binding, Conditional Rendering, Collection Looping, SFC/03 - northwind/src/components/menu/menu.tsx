import React, { Component } from "react";
import "./menu.css";

export class Menu extends Component {
    public render(): JSX.Element {
        return (
            <div className="menu">

                <a href="#">Home</a>

                <a href="#">Products</a>

                <a href="#">About</a>

            </div>
        );
    }
}