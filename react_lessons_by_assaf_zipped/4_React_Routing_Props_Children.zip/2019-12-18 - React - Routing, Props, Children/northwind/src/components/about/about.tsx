import React, { Component } from "react";
import "./about.css";
import { Thumbnail } from "../thumbnail/thumbnail";
import { Heading } from "../heading/heading";

export class About extends Component {
    public render(): JSX.Element {
        return (
            <div className="about">

                <Heading>Exotic Products from Around the World</Heading>

                <Thumbnail
                    imageSource="/assets/images/logo.jpg"
                    imageWidth={100}
                    imageHeight={100} />

                <Thumbnail
                    imageSource="/assets/images/logo.jpg"
                    imageWidth={70} />

            </div>
        );
    }
}