import React from "react";
import "./header.css";

// Stateless Functional Component
// שנבנה לא ע"י מחלקה, אלא ע"י פונקציה Component
// State אין לו
// props הוא כן יכול לקבל
// הוא יותר מהיר Performance מבחינת

export const Header: React.SFC = () => {
    return (
        <div className="header">
            <h1>Northwind Website</h1>
        </div>
    );
};