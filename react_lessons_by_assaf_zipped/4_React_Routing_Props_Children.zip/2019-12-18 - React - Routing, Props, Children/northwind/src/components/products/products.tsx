import React, { Component } from "react";
import "./products.css";
import { Heading } from "../heading/heading";

export class Products extends Component {
    public render(): JSX.Element {
        return (
            <div className="products">

                <Heading>Here are our Products:</Heading>

            </div>
        );
    }
}