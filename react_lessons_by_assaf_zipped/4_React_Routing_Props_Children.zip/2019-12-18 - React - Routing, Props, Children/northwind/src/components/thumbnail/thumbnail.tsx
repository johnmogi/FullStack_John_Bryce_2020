import React, { Component } from "react";
import "./thumbnail.css";

interface ThumbnailProps {
    imageSource: string;
    imageWidth: number;
    imageHeight?: number; // Optional Parameter
}

export class Thumbnail extends Component<ThumbnailProps> {
    public render(): JSX.Element {
        return (
            <div className="thumbnail">
                
                <img 
                    src={this.props.imageSource}
                    width={this.props.imageWidth}
                    height={this.props.imageHeight || 50} />

            </div>
        );
    }
}