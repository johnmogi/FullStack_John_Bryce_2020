

// Child: 
function doSomething(callback) {
    console.log("Starting doSomething...");
    if (callback) {
        callback();
    }
    console.log("Ending doSomething...");
}

// Parent: 
doSomething(function () {
    console.log("Starting the callback...");
    console.log("Ending the callback...");
});

console.log("---------------");

doSomething();





