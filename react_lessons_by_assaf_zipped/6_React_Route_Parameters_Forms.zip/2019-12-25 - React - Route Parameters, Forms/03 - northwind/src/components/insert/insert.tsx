import React, { Component, SyntheticEvent } from "react";
import "./insert.css";
import { Heading } from "../heading/heading";
import { ProductModel } from "../../models/product-model";

interface InsertState {
    product: ProductModel;
}

export class Insert extends Component<any, InsertState> {

    public constructor(props: any) {
        super(props);
        this.state = {
            product: new ProductModel()
        };
    }

    private setName = (args: SyntheticEvent) => {
        const name = (args.target as HTMLInputElement).value;
        console.log(name);
        
        // Set that name in the product in the state (this.setState...)
    };

    public render(): JSX.Element {
        return (
            <div className="insert">
                <Heading>Add new Product</Heading>
                <form>

                    <input type="text" placeholder="Name..." onChange={this.setName} value={this.state.product.name} />
                    <br /><br />

                    <input type="number" placeholder="Price..." />
                    <br /><br />

                    <input type="number" placeholder="Stock..." />
                    <br /><br />

                    <button type="button">Add</button>

                </form>

            </div>
        );
    }
}
