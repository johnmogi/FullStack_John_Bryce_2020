import React, { Component } from "react";
import "./menu.css";
import { NavLink } from "react-router-dom";

export class Menu extends Component {
    public render(): JSX.Element {
        return (
            <div className="menu">
                <NavLink to="/home" activeClassName="active-route" exact>Home</NavLink>
                <NavLink to="/products" activeClassName="active-route" exact>Products</NavLink>
                <NavLink to="/about" activeClassName="active-route" exact>About</NavLink>
            </div>
        );
    }
}