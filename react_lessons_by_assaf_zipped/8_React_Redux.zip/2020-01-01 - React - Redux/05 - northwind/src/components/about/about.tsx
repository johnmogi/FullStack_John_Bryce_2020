import React, { Component } from "react";
import "./about.css";
import { Thumbnail } from "../thumbnail/thumbnail";
import { Heading } from "../heading/heading";

export class About extends Component {

    public componentWillMount() {
        console.log("componentWillMount");
    }

    public componentDidMount() {
        console.log("componentDidMount");
    }

    public componentWillUnmount() {
        console.log("componentWillUnmount");
    }

    public render(): JSX.Element {
        console.log("render");
        return (
            <div className="about">

                <Heading>Exotic Products from Around the World</Heading>

                <Thumbnail
                    imageSource="/assets/images/logo.jpg"
                    imageWidth={100}
                    imageHeight={100} />

                <Thumbnail
                    imageSource="/assets/images/logo.jpg"
                    imageWidth={70} />

            </div>
        );
    }
}