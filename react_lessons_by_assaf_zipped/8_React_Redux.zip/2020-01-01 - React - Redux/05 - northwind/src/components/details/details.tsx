import React, { Component } from "react";
import "./details.css";
import { Heading } from "../heading/heading";
import { ProductModel } from "../../models/product-model";
import { NavLink } from "react-router-dom";
import { store } from "../../redux/store";

interface DetailsState {
    // product: ProductModel | null; // Union Types
    product: ProductModel
}

export class Details extends Component<any, DetailsState> {

    public constructor(props: any) {
        super(props);
        this.state = {
            product: null
        };
    }

    public componentDidMount(): void {

        // Get product id from the route: 
        const prodID = +this.props.match.params.prodID; // this.props.match.params = The route parameters, this.props.match.params.prodID = The prodID route parameter.

        // Without Redux: 
        // Get that product from the remote API: 
        // fetch("http://localhost:3001/products/" + prodID)
        //     .then(response => response.json()) // Convert to JSON
        //     .then(product => this.setState({ product }))
        //     .catch(err => alert(err.message));

        // With Redux: 
        const product = store.getState().products.find(p => p.id === prodID);
        this.setState({ product });
    }

    public render(): JSX.Element {
        return (
            <div className="details">

                <Heading>Product Details: </Heading>

                {this.state.product &&
                    <React.Fragment> {/* One Fragment to render its content for the conditional rendering */}
                        <p>Name: {this.state.product.name}</p>
                        <p>Price: {this.state.product.price}</p>
                        <p>Stock: {this.state.product.stock}</p>

                        <img src={`/assets/images/products/${this.state.product.id}.jpg`} />
                        <br /><br />

                        <NavLink to="/products" exact>Back to List</NavLink>
                        <span> | </span>
                        <a href="javascript:void" onClick={this.deleteProduct}>Delete</a>

                    </React.Fragment>
                }

            </div>
        );
    }

    private deleteProduct = () => {

        const answer = window.confirm("Are you sure?");
        if (!answer) {
            return;
        }

        const options = {
            method: "DELETE"
        };

        fetch("http://localhost:3001/products/" + this.state.product.id, options)
            .then(response => response.json())
            .then(() => {
                alert("Product has been successfully deleted.");
                this.props.history.push("/products"); // Redirect to "/products" route.
            })
            .catch(err => alert(err.message));
    };
}