import React, { Component, SyntheticEvent } from "react";
import "./insert.css";
import { Heading } from "../heading/heading";
import { ProductModel } from "../../models/product-model";
import { Action } from "../../redux/action";
import { ActionType } from "../../redux/action-type";
import { store } from "../../redux/store";

interface InsertState {
    product: ProductModel;
    errors: {
        nameError: string;
        priceError: string;
        stockError: string;
    }
}

export class Insert extends Component<any, InsertState> {

    public constructor(props: any) {
        super(props);
        this.state = {
            product: new ProductModel(),
            errors: {
                nameError: "*",
                priceError: "*",
                stockError: "*"
            }
        };
    }

    private setName = (args: SyntheticEvent) => {
        const name = (args.target as HTMLInputElement).value;
        const product = { ...this.state.product }; // Spread Operator
        product.name = name;

        const errors = { ...this.state.errors };
        if (name === "") {
            errors.nameError = "Missing name";
        }
        else if (name.length > 10) {
            errors.nameError = "Name too long"
        }
        else {
            errors.nameError = "";
        }

        this.setState({ product, errors });
    };

    private setPrice = (args: SyntheticEvent) => {
        const price = +(args.target as HTMLInputElement).value;
        const product = { ...this.state.product };
        product.price = price;

        const errors = { ...this.state.errors };
        if (price < 0) {
            errors.priceError = "Price can't be negative";
        }
        else if (price > 1000) {
            errors.priceError = "Price can't exceeds 1000";
        }
        else {
            errors.priceError = "";
        }

        this.setState({ product, errors });
    };

    private setStock = (args: SyntheticEvent) => {
        const stock = +(args.target as HTMLInputElement).value;
        const product = { ...this.state.product };
        product.stock = stock;
        const errors = { ...this.state.errors };

        if (stock < 0) {
            errors.stockError = "Stock can't be negative";
        }
        else if (stock > 1000) {
            errors.stockError = "Stock can't exceeds 1000";
        }
        else {
            errors.stockError = "";
        }

        this.setState({ product, errors });
    };

    private addProduct = () => {

        if (!this.isFormLegal()) {
            alert("Please correct all errors!");
            return;
        }
        
        const options = {
            method: "POST",
            headers: {
                "Content-Type": "application/json", // What type we are sending (MIME Types)
                "Accept": "application/json" // What type we are expecting to get back (MIME Types)
            },
            body: JSON.stringify(this.state.product) // What data we are sending
        };

        fetch("http://localhost:3001/products", options)
            .then(response => response.json())
            .then(product => {
                alert("Product has been successfully added. ID: " + product.id);

                // With Redux: 
                const action: Action = { // Create action for adding a product.
                    type: ActionType.AddProduct,
                    payload: product
                };
                store.dispatch(action); // Do it - add the product to the store.

                this.props.history.push("/products"); // Redirect to "/products" route.
            })
            .catch(err => alert(err.message));
    };

    private isFormLegal = () => {
        return this.state.errors.nameError === "" &&
            this.state.errors.priceError === "" &&
            this.state.errors.stockError === "";
    };

    public render(): JSX.Element {
        return (
            <div className="insert">
                <Heading>Add new Product</Heading>
                <form>
                    <input type="text" placeholder="Name..." onChange={this.setName} value={this.state.product.name || ""} />
                    <span>{this.state.errors.nameError}</span>
                    <br /><br />

                    <input type="number" placeholder="Price..." onChange={this.setPrice} value={this.state.product.price || ""} />
                    <span>{this.state.errors.priceError}</span>
                    <br /><br />

                    <input type="number" placeholder="Stock..." onChange={this.setStock} value={this.state.product.stock || ""} />
                    <span>{this.state.errors.stockError}</span>
                    <br /><br />

                    <button disabled={!this.isFormLegal()} type="button" onClick={this.addProduct}>Add</button>

                </form>

            </div>
        );
    }
}
