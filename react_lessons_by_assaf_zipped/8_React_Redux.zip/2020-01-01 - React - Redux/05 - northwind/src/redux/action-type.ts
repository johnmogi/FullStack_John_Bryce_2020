
// רשימת הפעולות הדרושות לביצוע על המידע שברמת האפליקציה

export enum ActionType {
    LoadAllProducts,
    AddProduct,
    UpdateProduct,
    DeleteProduct,
    ClearAllProducts
    //...
}