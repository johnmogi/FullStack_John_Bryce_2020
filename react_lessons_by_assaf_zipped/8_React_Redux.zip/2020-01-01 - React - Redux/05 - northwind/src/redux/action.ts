import { ActionType } from "./action-type";

// Action - הפעולה הדרושה לביצוע + המידע שלה

export interface Action {
    type: ActionType, // הפעולה הדרושה לביצוע
    payload?: any // המידע שלה - לא חובה שיהיה לה מידע
}