import { ProductModel } from "../models/product-model";

// המידע הקיים ברמת האפליקציה

export class AppState {
    public products: ProductModel[] = [];
    // public customers: CustomerModel[] = [];
    // public employees: EmployeeModel[] = [];
}