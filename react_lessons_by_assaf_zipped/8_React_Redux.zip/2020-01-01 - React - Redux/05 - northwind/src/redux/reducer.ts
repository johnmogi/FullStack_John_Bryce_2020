import { AppState } from "./app-state";
import { Action } from "./action";
import { ActionType } from "./action-type";

// Reducer - פונקציה המבצעת את הפעולה הדרושה על המידע
// פונקציה זו צריכה לקבל שני פרמטרים:
// AppState-פרמטר ראשון - אובייקט ה
// Action-פרמטר שני - אובייקט ה
// שנשלח אליה AppState-אבל - אסור לפונקציה לשנות את ה
// חדש, לשנות אותו ולהחזיר אותו AppState לכן היא חייבת לייצר

export function reducer(oldState: AppState, action: Action): AppState {

    const newState = { ...oldState }; // Spread Operator

    switch(action.type) {

        case ActionType.LoadAllProducts: // אם הפעולה לביצוע הינה לטעון את כל המוצרים מהשרת
            newState.products = action.payload; // לכן נכניס אותם למערך המוצרים payload-כל המוצרים נמצאים ב
            break;

        case ActionType.AddProduct: // אם הפעולה לביצוע הינה להוסיף מוצר אחד
            newState.products.push(action.payload); // ואנו מוסיפים אותו למערך payload-המוצר הבודד נמצא ב
            break;

        case ActionType.DeleteProduct: // אם הפעולה לביצוע הינה למחוק מוצר
            const indexToDelete = newState.products.findIndex(p => p.id === action.payload); // מציאת המיקום של המוצר למחיקה
            newState.products.splice(indexToDelete, 1); // מחיקת המוצר
            break;

        // .......
    }

    return newState;
}
