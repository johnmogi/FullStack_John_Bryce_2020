import { createStore } from "redux";
import { reducer } from "./reducer";
import { AppState } from "./app-state";

// Store = AppState-החנות עצמה - מכילה את אובייקט ה

export const store = createStore(reducer, new AppState());

